<?php

    // Start the session
    session_start();

    // destroy the session
    session_destroy();
    // echo $_SESSION["email"];

    echo "Successfully logged out!"
    ?>