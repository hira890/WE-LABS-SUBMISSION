<?php
		echo "<h1> Access Allowed <h1>";
?>