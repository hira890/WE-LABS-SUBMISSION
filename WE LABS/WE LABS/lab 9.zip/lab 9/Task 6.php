<!DOCTYPE html>
<html>
    <head>
        <title>Random Numbers</title>
    </head>
    <body>
        <?php 
            $arr = array();
            for ($i = 0; $i < 10; $i++) {
                $randomNumber = rand(1, 200);
                array_push($arr, $randomNumber);
            }

            $rollNumber = 82;
            if (in_array($rollNumber, $arr)) {
                echo "I found you !!<br>";
            }
            else {
                echo "Opps couldn't find you !! <br>";
            }

        ?>
    </body>
</html>