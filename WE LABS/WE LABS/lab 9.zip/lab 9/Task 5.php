<!DOCTYPE html>
<html>
    <head>
        <title></title>
    </head>
    <body>
        <?php 
            // sort the following associative array 
            $arr = array(
                "Samreen" => "31",
                "Jahan" => "41",
                "Warisha" => "39",
                "Rania" => "40"
            );

            // ascending order sort by value
            asort($arr);
            echo "Array sorted in ascending order by value <br> <br>";
            foreach ($arr as $key => $value) {
                echo $key." is ".$value." years old <br>";
            }

            echo "<br> <br>";

            // ascending order sort by key 
            ksort($arr);
            echo "Array sorted in ascending order by key <br> <br>";
            foreach ($arr as $key => $value) {
                echo $key." is ".$value." years old <br>";
            }

            echo "<br> <br>";

            // descending order sorting by value 
            arsort($arr);
            echo "Array sorted in descending order by value <br> <br>";
            foreach ($arr as $key => $value) {
                echo $key." is ".$value." years old <br>";
            }  

            echo "<br> <br>";

            // descending order sorting by key 
            krsort($arr);
            echo "Array sorted in descending order by key <br> <br>";
            foreach ($arr as $key => $value) {
                echo $key." is ".$value." years old <br>";
            }
        ?>
    </body>
</html>